#!/bin/bash

# Script d'installation du Superviseur DHCP
# Créé l'arborescence et installe les dépendances

set -e  # Arrêter en cas d'erreur

echo "=== Installation du Superviseur DHCP ==="
echo

# Définir le répertoire de base
BASE_DIR="$HOME/superviseur-dhcp-code"

# Fonction pour afficher les messages
log_info() {
    echo "[INFO] $1"
}

log_error() {
    echo "[ERREUR] $1" >&2
}

log_success() {
    echo "[SUCCÈS] $1"
}

# Vérifier si Python 3.6+ est installé
check_python() {
    log_info "Vérification de Python..."
    if command -v python3 >/dev/null 2>&1; then
        PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
        REQUIRED_VERSION="3.6"
        
        if python3 -c "import sys; exit(0 if sys.version_info >= (3,6) else 1)" 2>/dev/null; then
            log_success "Python $PYTHON_VERSION trouvé (>= 3.6)"
        else
            log_error "Python $PYTHON_VERSION trouvé mais version >= 3.6 requise"
            exit 1
        fi
    else
        log_error "Python 3 n'est pas installé"
        log_info "Veuillez installer Python 3.6+ avant de continuer"
        exit 1
    fi
}

# Vérifier si pip3 est installé
check_pip() {
    log_info "Vérification de pip3..."
    if command -v pip3 >/dev/null 2>&1; then
        log_success "pip3 trouvé"
    else
        log_error "pip3 n'est pas installé"
        log_info "Veuillez installer pip3 avant de continuer"
        exit 1
    fi
}

# Créer l'arborescence
create_structure() {
    log_info "Création de l'arborescence dans $BASE_DIR..."
    
    # Supprimer le répertoire s'il existe déjà
    if [ -d "$BASE_DIR" ]; then
        log_info "Le répertoire $BASE_DIR existe déjà, suppression..."
        rm -rf "$BASE_DIR"
    fi
    
    # Créer les répertoires
    mkdir -p "$BASE_DIR/bin"
    mkdir -p "$BASE_DIR/src"
    
    log_success "Arborescence créée"
}

# Copier les fichiers depuis le répertoire courant
copy_files() {
    log_info "Copie des fichiers..."
    
    # Copier le fichier de configuration
    if [ -f "superviseur.yaml" ]; then
        cp "superviseur.yaml" "$BASE_DIR/"
        log_success "superviseur.yaml copié"
    else
        log_error "superviseur.yaml non trouvé dans le répertoire courant"
        exit 1
    fi
    
    # Copier les scripts exécutables
    SCRIPTS=("add-dhcp-client.py" "remove-dhcp-client.py" "list-dhcp.py" "check-dhcp.py")
    for script in "${SCRIPTS[@]}"; do
        if [ -f "$script" ]; then
            cp "$script" "$BASE_DIR/bin/"
            chmod +x "$BASE_DIR/bin/$script"
            log_success "$script copié et rendu exécutable"
        else
            log_error "$script non trouvé dans le répertoire courant"
            exit 1
        fi
    done
    
    # Copier les modules Python
    MODULES=("config.py" "validation.py" "dhcp.py")
    for module in "${MODULES[@]}"; do
        if [ -f "$module" ]; then
            cp "$module" "$BASE_DIR/src/"
            log_success "$module copié"
        else
            log_error "$module non trouvé dans le répertoire courant"
            exit 1
        fi
    done
}

# Installer les dépendances Python
install_dependencies() {
    log_info "Installation des dépendances Python..."
    
    # Mettre à jour pip3
    log_info "Mise à jour de pip3..."
    pip3 install --upgrade pip
    
    # Installer les paquets requis
    PACKAGES=("fabric" "paramiko" "pyyaml")
    for package in "${PACKAGES[@]}"; do
        log_info "Installation de $package..."
        pip3 install "$package"
        log_success "$package installé"
    done
}

# Créer un fichier __init__.py dans src pour en faire un package Python
create_init_file() {
    log_info "Création du fichier __init__.py..."
    touch "$BASE_DIR/src/__init__.py"
    log_success "Package Python créé"
}

# Ajouter le répertoire bin au PATH
add_to_path() {
    log_info "Ajout du répertoire bin au PATH..."
    
    BASHRC_FILE="$HOME/.bashrc"
    PATH_LINE='export PATH="$PATH:~/superviseur-dhcp-code/bin"'
    
    # Vérifier si la ligne existe déjà
    if grep -q "superviseur-dhcp-code/bin" "$BASHRC_FILE" 2>/dev/null; then
        log_info "Le PATH est déjà configuré dans ~/.bashrc"
    else
        # Ajouter la ligne au .bashrc
        echo "" >> "$BASHRC_FILE"
        echo "# Superviseur DHCP - Ajouté automatiquement" >> "$BASHRC_FILE"
        echo "$PATH_LINE" >> "$BASHRC_FILE"
        log_success "PATH ajouté à ~/.bashrc"
        log_info "Redémarrez votre terminal ou tapez: source ~/.bashrc"
    fi
}

# Afficher l'arborescence finale
show_structure() {
    log_info "Structure finale créée :"
    echo
    tree "$BASE_DIR" 2>/dev/null || {
        echo "$BASE_DIR/"
        echo "├── superviseur.yaml"
        echo "├── bin/"
        echo "│   ├── add-dhcp-client.py"
        echo "│   ├── remove-dhcp-client.py"
        echo "│   ├── list-dhcp.py"
        echo "│   └── check-dhcp.py"
        echo "└── src/"
        echo "    ├── __init__.py"
        echo "    ├── config.py"
        echo "    ├── validation.py"
        echo "    └── dhcp.py"
    }
    echo
}



# Fonction principale
main() {
    echo "Début de l'installation..."
    echo
    
    # Vérifications préalables
    check_python
    check_pip
    
    # Installation
    create_structure
    copy_files
    install_dependencies
    create_init_file
    add_to_path
    
    # Affichage final
    show_structure
    
    echo
    log_success "Installation terminée avec succès !"
    echo
    echo "Le Superviseur DHCP a été installé dans : $BASE_DIR"
    echo "Tous les scripts dans bin/ sont exécutables"
    echo "Les commandes sont maintenant disponibles globalement !"
    echo
    echo "Vous pouvez maintenant utiliser les commandes directement :"
    echo "  add-dhcp-client.py"
    echo "  remove-dhcp-client.py"
    echo "  list-dhcp.py"
    echo "  check-dhcp.py"
    echo
    echo "Note: Pour les nouvelles sessions de terminal, redémarrez votre terminal"
    echo "ou tapez: source ~/.bashrc"
}

# Exécuter le script principal
main "$@"
